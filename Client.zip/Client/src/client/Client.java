/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.io.IOException;
import java.net.UnknownHostException;

/**
 *
 * @author tukalov_ev
 */
public class Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws UnknownHostException, IOException {
        String serverName = "OFFICE13571";
        //serverName = "localhost";
        ClientModel model = new ClientModel(serverName, 8080);
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Main main = new Main(model);
                main.setVisible(true);
                main.notifyListener();
            }
        });
    }
    
}
