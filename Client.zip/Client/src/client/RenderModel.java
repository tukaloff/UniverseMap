/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import cmd.State;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author tukalov_ev
 */
public class RenderModel {
    
    private ClientModel _clientModel;
    private BufferedImage _bi;

    public RenderModel(ClientModel model) {
        this._clientModel = model;
    }

    public BufferedImage getImage() {
        return _bi;
    }
    
    public void sendAction(char ch) {
        _clientModel.sendAction(ch);
    }

    public void paint() {
        State state = _clientModel.getState();
        if (state == null) {
            _bi = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
            return;
        }
        _bi = new BufferedImage(state.map.Width
                , state.map.Height
                , BufferedImage.TYPE_INT_ARGB);
        Graphics g = _bi.getGraphics();
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, _bi.getWidth(), _bi.getHeight());
        state.players.forEach((p) -> {
            _bi.setRGB(p.Location.X, p.Location.Y, Color.WHITE.getRGB());
            _bi.getGraphics().drawString(p.Name, p.Location.X, p.Location.Y);
        });
        _bi.flush();
    }

    void run() {
        new Thread(()->{
            while(true) {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException ex) {
                    Logger.getLogger(RenderModel.class.getName()).log(Level.SEVERE, null, ex);
                }
                paint();
            }
        }).start();
    }
}
