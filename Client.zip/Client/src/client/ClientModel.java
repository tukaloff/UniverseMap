/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import cmd.Action;
import cmd.Command;
import cmd.Commands;
import cmd.Location;
import cmd.Message;
import cmd.State;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author tukalov_ev
 */
public class ClientModel {
    
    private Socket _outsoc;
    //private Socket _insoc;
    private ObjectInputStream _in;
    private ObjectOutputStream _out;
    private List<Message> _messages;
    private Main _listener;
    private State _state;
    
    public ClientModel(String host, int port) throws UnknownHostException, IOException {
        _outsoc = new Socket(host, port);
        //_insoc = new ServerSocket(8081).accept();
        System.out.println("Connected in socket");
        _out = new ObjectOutputStream(_outsoc.getOutputStream());
        _in = new ObjectInputStream(_outsoc.getInputStream());
        _messages = new ArrayList<>();
        reseiveMessage();
    }
    
    public void sendMessage(String message) {
        send(new Message("", message));
    }
    
    private void send(Command c) {
        try {
            _out.writeObject(c);
            _out.flush();
        } catch (IOException ex) {
            System.err.println(ex.getLocalizedMessage());
        }
    }
    
    private void reseiveMessage() {
        new Thread(()-> {
            while(true) {
                try {
                    Command cmd = (Command) _in.readObject();
                    switch(cmd.getType()) {
                        case Message:
                            _messages.add((Message)cmd);
                            break;
                        case State:
                            _state = (State)cmd;
                            break;
                            //System.out.println((State)cmd);
                    }
                    if (_listener != null) _listener.notifyListener();
                } catch (Exception ex) {
                    System.err.println("reseiveMessage: " + ex.getLocalizedMessage());
                }
            }
        }).start();
    }

    public void setListener(Main listener) {
        this._listener = listener;
        _listener.setTitle("" + _outsoc.getLocalPort());
    }
    
    public List<Message> getMessages() {
        return _messages;
    }
    
    public State getState() {
        return _state;
    }

    public RenderModel createRenderModel() {
        RenderModel rm = new RenderModel(this);
        rm.run();
        return rm;
    }

    void sendAction(char ch) {
        switch (ch) {
            case 'w':
                send(new Action(Commands.Move, new Location(0, -1, 0)));
                break;
            case 'a':
                send(new Action(Commands.Move, new Location(-1, 0, 0)));
                break;
            case 's':
                send(new Action(Commands.Move, new Location(0, 1, 0)));
                break;
            case 'd':
                send(new Action(Commands.Move, new Location(1, 0, 0)));
                break;
        }
    }
}
