/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package srv;

import cmd.Action;
import cmd.Command;
import cmd.Message;
import cmd.Player;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author tukalov_ev
 */
class User {
    
    private Socket _insoc;
    //private Socket _outsoc;
    private Server _srv;
    private ObjectInputStream _in;
    private ObjectOutputStream _out;
    private Player _player;
    
    public User(Socket client, Server srv, Player p) throws IOException {
        this._insoc = client;
        //this._outsoc = new Socket(_insoc.getInetAddress().getHostName(), 8081);
        this._srv = srv;
        this._player = p;
        this._out = new ObjectOutputStream(_insoc.getOutputStream());
        this._in = new ObjectInputStream(_insoc.getInputStream());
        send(new Message("server", "Connected: " + _srv));
        runRead();
    }
    
    private void runRead() {
        new Thread(()->{
            while (true)
                try {
                    Command cmd = (Command) _in.readObject();
                    switch(cmd.getType()) {
                        case Message:
                            Message msg = (Message) cmd;
                            String line = msg.message;
                            _srv.notify(this, line);
                            System.out.println(this.toString() + ": " + line);
                            break;
                        case Action:
                            Action act = (Action) cmd;
                            _srv.doAction(this._player, act);
                            break;
                            
                    }
                } catch (IOException ex) { 
                    try { 
                        _insoc.close(); 
                    } catch (IOException ex1) {}
                    break;
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
                }
            _srv.disconnectUser(this);
        }).start();
    }
    
    public void send(Command msg) throws IOException {
        _out.reset();
        _out.writeObject(msg);
    }
    
    @Override
    public String toString() {
        //return _soc.toString();
        return "" + _insoc.getPort();
    }

    public Player getPlayer() {
        return _player;
    }
}