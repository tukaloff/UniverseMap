/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package srv;

import cmd.Action;
import cmd.Command;
import cmd.Location;
import cmd.Message;
import cmd.Player;
import cmd.State;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 *
 * @author tukalov_ev
 */
public class Server {
    
    private Queue<Command> _cmds;
    private Queue<User> _users;
    private int _port;
    private long _tickTime = 0;
    private State _state;
    
    public Server(int port) throws IOException {
        this._port = port;
        ServerSocket socket = new ServerSocket(this._port);
        _users = new ConcurrentLinkedQueue<>();
        _cmds = new PriorityQueue<>((Command o1, Command o2) -> 0);
        _state = new State();
        _state.setMapSize(256, 256, 0);
        new Thread(()->{run();}).start();
        while (true) { _users.add(connectUser(socket)); }
    }
    
    private User connectUser(ServerSocket socket) throws IOException {
        Socket client = socket.accept();
        Player p = new Player("" + client.getPort(), Location.random(_state.map));
        User user = new User(client, this, p);
        _state.addPlayer(p);
        System.out.println("Connected: " + user.toString());
        return user;
    }
    
    public void disconnectUser(User user) {
        System.out.println("Disconnected: " + user.toString());
        _users.remove(user);
        _state.removePlayer(user.getPlayer());
    }
    
    public void notify(User sender, String message) {
        _cmds.offer(new Message(sender.toString(), message));
    }
    
    public void run() {
        long startTime;
        while(true) {
            try {
                Thread.sleep(10);
            } catch (InterruptedException ex) {}
            startTime = System.currentTimeMillis();
            tick();
            _tickTime = System.currentTimeMillis() - startTime;
        }
    }
    
    private void tick() {
        sendEachUser(_state);
        //System.out.println(_state.toString());
        Command msg = _cmds.poll();
        while (msg != null) {
            System.out.println("tick: " + _tickTime);
            switch(msg.getType()) {
                case Message:
                    sendEachUser(msg);
                    break;
            }
            msg = _cmds.poll();
        }
    }
    
    private void sendEachUser(Command msg) {
        _users.forEach((user) -> {
            try { user.send(msg); } catch (IOException ex) {}
        });
    }
    
    @Override
    public String toString() {
        return "" + this._port;
    }

    void doAction(Player player, Action act) {
        switch(act.action) {
            case Move:
                _state.movePlayer(player, act.toLocation);
                break;
        }
    }
}
