/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package srv;

import java.io.IOException;

/**
 *
 * @author tukalov_ev
 */
public class Srv {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) throws IOException {
        Server srv = new Server(8080);
    }
}
