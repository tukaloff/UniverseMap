package cmd;

import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author tukalov_ev
 */
public class Message implements Command {
    
    public Commands type;
    public String sender;
    public String message;
    
    public Message(String s, String msg) {
        this.sender = s;
        this.message = msg;
        this.type = Commands.Message;
    }

    @Override
    public Commands getType() {
        return type;
    }
}
