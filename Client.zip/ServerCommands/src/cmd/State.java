/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cmd;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author tukalov_ev
 */
public class State implements Command {
    
    public Commands type;
    public List <Player> players;
    public Map map;
    
    public State() {
        type = Commands.State;
        this.players = new ArrayList<>();
    }
    
    public void setMapSize(int w, int h, int d) {
        map = new Map(w, h, d);
    }
    
    public void addPlayer(Player p) {
        this.players.add(p);
    }
    
    public void removePlayer(Player p) {
        this.players.remove(p);
    }

    @Override
    public Commands getType() {
        return this.type;
    }
    
    @Override
    public String toString() {
        String l = "";
        for(Player p : players) l += p.toString() + "\n";
        return "Players: " + players.size() + "\n" +  l;
    }

    public void movePlayer(Player player, Location toLocation) {
        int x = player.Location.X + toLocation.X;
        int y = player.Location.Y + toLocation.Y;
        int z = player.Location.Z + toLocation.Z;
        if (!(x >= map.Width || x < 0)) player.Location.X = x;
        if (!(y >= map.Height || y < 0)) player.Location.Y = y;
        if (!(z >= map.Depth || z < 0)) player.Location.Z = z;
    }
}
