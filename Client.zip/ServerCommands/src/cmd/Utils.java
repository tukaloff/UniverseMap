/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cmd;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;

/**
 *
 * @author tukalov_ev
 */
public class Utils {
    
    public static byte[] toBytes(Command cmd) {
        ByteArrayOutputStream bos = null;
        byte[] bytes = null;
        try {
            bos = new ByteArrayOutputStream();
            ObjectOutput out = new ObjectOutputStream(bos);
            out.writeObject(cmd);
            out.flush();
            bytes = bos.toByteArray();
        } catch (IOException ex) {System.out.println(ex.getLocalizedMessage());} 
        finally {
            try { bos.close(); } 
            catch (IOException ex) {}
        }
        return bytes;
    }
    
    public static Command fromBytes(byte[] bytes) {
        ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
        Command cmd = null;
        ObjectInput in = null;
        try {
            in = new ObjectInputStream(bis);
            cmd = (Command) in.readObject();
        } catch (IOException | ClassNotFoundException ex) {System.err.println("fromBytes: " + ex.getLocalizedMessage());} 
        finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception e) {System.err.println(e.getLocalizedMessage());}
        }
        return cmd;
    }
}
