/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cmd;

/**
 *
 * @author tukalov_ev
 */
public class Player implements Command{
    
    public Commands type;
    public String Name;
    public Location Location;
    
    public Player(String name, Location loc) {
        this.Name = name;
        this.Location = loc;
        this.type = Commands.Player;
    }

    @Override
    public Commands getType() {
        return type;
    }
    
    @Override
    public String toString() {
        return Name + "[" + Location + "]";
    }
}
