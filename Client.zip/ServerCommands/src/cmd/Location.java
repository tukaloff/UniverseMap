/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cmd;

/**
 *
 * @author tukalov_ev
 */
public class Location implements Command{
    
    public Commands type;
    public int X, Y, Z;

    public Location(int x, int y, int z) {
        this.X = x;
        this.Y = y;
        this.Z = z;
        
        this.type = Commands.Location;
    }
    
    public static Location random(Map map) {
        return new Location((int) (Math.random() * map.Width)
                , (int) (Math.random() * map.Height)
                , (int) (Math.random() * map.Depth));
    }

    @Override
    public Commands getType() {
        return type;
    }
    
    @Override
    public String toString() {
        return "loc[" + X + ", " + Y + ", " + Z + "]";
    }
}
