/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cmd;

/**
 *
 * @author tukalov_ev
 */
public class Map implements Command {
    
    public Commands type;
    
    public int Width, Height, Depth;
    public int[][][] map;
    
    public Map(int w, int h, int d) {
        this.Width = w;
        this.Height = h;
        this.Depth = d;
        //this.map = new int[w][h][d];
        
        this.type = Commands.Map;
    }

    @Override
    public Commands getType() {
        return type;
    }
}
